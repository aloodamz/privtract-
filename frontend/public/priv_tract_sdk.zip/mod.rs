//! ╔══════════════════════════════════════════════════════════════════════╗
//! ║                  PRIV-TRACT POLICY ENGINE SDK v1.0.0               ║
//! ║         Enterprise-grade AI Agent Transaction Gatekeeper           ║
//! ║                                                                    ║
//! ║  Dual-mode SDK: Local embedded enforcement + Remote gateway API    ║
//! ║  Cryptographic privacy: SHA-256 & BLAKE3 identity masking          ║
//! ║  Solana-native: Base58 addressing, lamport arithmetic, PDA seeds   ║
//! ╚══════════════════════════════════════════════════════════════════════╝
//!
//! # Architecture
//!
//! ```text
//! ┌────────────────────┐       ┌──────────────────────────────┐
//! │   AI Agent / Bot   │──────▶│      PrivTractSDK            │
//! │                    │       │                              │
//! │  tx = Transaction  │       │  ┌──────────┐ ┌───────────┐ │
//! │  sdk.evaluate(tx)  │       │  │ Embedded │ │ Gateway   │ │
//! │                    │       │  │ Engine   │ │ Client    │ │
//! └────────────────────┘       │  │ (local)  │ │ (remote)  │ │
//!                              │  └─────┬────┘ └─────┬─────┘ │
//!                              │  ┌─────▼────────────▼─────┐ │
//!                              │  │  Crypto Layer          │ │
//!                              │  │  SHA-256 · BLAKE3      │ │
//!                              │  │  bs58 · hex · U256     │ │
//!                              │  └────────────────────────┘ │
//!                              └──────────────────────────────┘
//! ```
//!
//! # Quick Start — Embedded Mode (zero network, pure local)
//!
//! ```rust,no_run
//! use priv_tract::priv_tract_sdk::*;
//!
//! #[tokio::main]
//! async fn main() {
//!     let sdk = PrivTractSDK::from_config("config.toml").unwrap();
//!
//!     // Hash agent + recipient for privacy
//!     let agent = sdk.hash_agent_sha256(1);
//!     let recipient = sdk.hash_address_sha256("SRMu8tBssHvwJZ1J4GoAWb8R749547rK1N6rRc13qD2");
//!
//!     let tx = SdkTransaction {
//!         from_agent: agent,
//!         to: recipient,
//!         value_lamports: 1_000_000,  // 0.001 SOL
//!         priority_fee: 5000,
//!         cluster_id: 102,            // Solana devnet
//!         instruction_data: None,
//!     };
//!
//!     match sdk.evaluate(&tx) {
//!         Ok(receipt) => println!("✅ APPROVED: {}", receipt.message),
//!         Err(denial) => println!("❌ DENIED:   {}", denial),
//!     }
//! }
//! ```

#[cfg(test)]
mod tests;

use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

use serde::{Deserialize, Serialize};
use sha2::{Sha256, Digest as Sha2Digest};

// ═══════════════════════════════════════════════════════════════════════
//  SECTION 1: CRYPTOGRAPHIC PRIMITIVES
//  SHA-256 and BLAKE3 hashing with constant-time comparison
// ═══════════════════════════════════════════════════════════════════════

/// 32-byte cryptographic digest. Used for both SHA-256 and BLAKE3.
pub type Hash256 = [u8; 32];

/// Compute SHA-256 digest over raw bytes.
///
/// Uses the NIST FIPS 180-4 standard via the `sha2` crate which leverages
/// hardware SHA extensions (SHA-NI on x86, SHA2 on ARMv8) when available,
/// falling back to a constant-time software implementation otherwise.
#[inline]
pub fn sha256_digest(data: &[u8]) -> Hash256 {
    let mut hasher = Sha256::new();
    hasher.update(data);
    let result = hasher.finalize();
    let mut out = [0u8; 32];
    out.copy_from_slice(&result);
    out
}

/// Compute SHA-256 of a UTF-8 string. Mirrors the server engine's `sha256_hash`.
#[inline]
pub fn sha256_str(s: &str) -> Hash256 {
    sha256_digest(s.as_bytes())
}

/// Compute BLAKE3 digest over raw bytes.
///
/// BLAKE3 is a parallel Merkle-tree hash designed for throughput. On modern
/// hardware it processes >1 GiB/s on a single core using SIMD (NEON / AVX-512).
/// For short inputs (<1 KiB) such as Solana pubkeys, the single-block fast
/// path is taken automatically—no thread pool overhead.
#[inline]
pub fn blake3_digest(data: &[u8]) -> Hash256 {
    *blake3::hash(data).as_bytes()
}

/// Compute BLAKE3 of a UTF-8 string. Mirrors the server engine's `blake3_hash`.
#[inline]
pub fn blake3_str(s: &str) -> Hash256 {
    blake3_digest(s.as_bytes())
}

/// Constant-time comparison of two 32-byte digests.
///
/// Prevents timing side-channel leaks when comparing hashed identifiers
/// across trust boundaries. Compiles down to a branchless XOR-fold on
/// all tier-1 targets (aarch64, x86_64).
#[inline]
pub fn ct_hash_eq(a: &Hash256, b: &Hash256) -> bool {
    let mut acc: u8 = 0;
    for i in 0..32 {
        acc |= a[i] ^ b[i];
    }
    acc == 0
}

/// Format a 32-byte hash as `"sha256:<hex>"` for wire transport.
#[inline]
pub fn fmt_sha256(h: &Hash256) -> String {
    format!("sha256:{}", hex::encode(h))
}

/// Format a 32-byte hash as `"blake3:<hex>"` for wire transport.
#[inline]
pub fn fmt_blake3(h: &Hash256) -> String {
    format!("blake3:{}", hex::encode(h))
}

/// Decode a Solana Base58 pubkey string into raw 32 bytes.
/// Returns an error if the decoded length is not exactly 32.
pub fn decode_solana_pubkey(s: &str) -> Result<[u8; 32], SdkError> {
    let bytes = bs58::decode(s.trim())
        .into_vec()
        .map_err(|e| SdkError::InvalidAddress(format!("base58 decode: {e}")))?;
    if bytes.len() != 32 {
        return Err(SdkError::InvalidAddress(format!(
            "expected 32 bytes, got {}", bytes.len()
        )));
    }
    let mut arr = [0u8; 32];
    arr.copy_from_slice(&bytes);
    Ok(arr)
}

/// Encode raw 32 bytes as a Solana Base58 pubkey string.
#[inline]
pub fn encode_solana_pubkey(bytes: &[u8; 32]) -> String {
    bs58::encode(bytes).into_string()
}

/// Derive a Solana Program-Derived Address (PDA) seed buffer.
///
/// PDAs are off-curve Ed25519 points used as deterministic account
/// addresses. This helper produces the seed byte array that the
/// on-chain program expects for wallet-config and agent-state accounts.
///
/// ```text
/// WalletConfig PDA: seeds = [b"wallet-config", authority_pubkey]
/// AgentState PDA:   seeds = [b"agent-state",   agent_id.to_le_bytes()]
/// ```
pub fn pda_seeds_wallet_config(authority: &[u8; 32]) -> Vec<Vec<u8>> {
    vec![
        b"wallet-config".to_vec(),
        authority.to_vec(),
    ]
}

pub fn pda_seeds_agent_state(agent_id: u64) -> Vec<Vec<u8>> {
    vec![
        b"agent-state".to_vec(),
        agent_id.to_le_bytes().to_vec(),
    ]
}


// ═══════════════════════════════════════════════════════════════════════
//  SECTION 2: ERROR TYPES
// ═══════════════════════════════════════════════════════════════════════

/// Policy denial reasons. Mirrors the on-chain `ProgramError::Custom(N)`
/// codes and the off-chain `PolicyError` enum variants one-to-one.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PolicyDenial {
    /// Kill switch is active — all transactions globally halted.
    KillSwitchActive,
    /// Agent ID / hash not found in the registered agent table.
    AgentNotAuthenticated,
    /// Destination address / hash not in the recipient allowlist.
    RecipientNotWhitelisted,
    /// Single transaction value exceeds agent or wallet per-tx limit.
    TransactionLimitExceeded,
    /// Agent's cumulative daily spend would exceed the agent daily cap.
    AgentDailyCapExceeded,
    /// Wallet-wide cumulative daily spend would exceed the global cap.
    WalletDailyCapExceeded,
    /// Transaction targets wrong Solana cluster (devnet vs mainnet).
    ClusterIdMismatch,
    /// Priority fee exceeds the configured maximum safe ceiling.
    PriorityFeeTooHigh,
    /// Instruction data present but contract calls are disabled.
    InstructionCallsNotAllowed,
    /// Instruction discriminator not in the function selector allowlist.
    InstructionSelectorNotWhitelisted,
    /// Daily transaction count limit exceeded for this agent.
    TransactionCountLimitExceeded,
}

impl std::fmt::Display for PolicyDenial {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::KillSwitchActive =>
                write!(f, "DENIED: Global emergency kill-switch is active. All transactions halted."),
            Self::AgentNotAuthenticated =>
                write!(f, "DENIED: Agent identity not authenticated. Hash does not match any registered agent."),
            Self::RecipientNotWhitelisted =>
                write!(f, "DENIED: Recipient address/hash not found in the allowlist."),
            Self::TransactionLimitExceeded =>
                write!(f, "DENIED: Transaction value exceeds the per-transaction limit."),
            Self::AgentDailyCapExceeded =>
                write!(f, "DENIED: Agent cumulative daily spend would exceed daily cap."),
            Self::WalletDailyCapExceeded =>
                write!(f, "DENIED: Wallet-wide cumulative daily spend cap exceeded."),
            Self::ClusterIdMismatch =>
                write!(f, "DENIED: Target cluster/chain ID does not match the configured network."),
            Self::PriorityFeeTooHigh =>
                write!(f, "DENIED: Priority fee exceeds the maximum allowed ceiling."),
            Self::InstructionCallsNotAllowed =>
                write!(f, "DENIED: Program instruction calls are globally disabled."),
            Self::InstructionSelectorNotWhitelisted =>
                write!(f, "DENIED: Instruction discriminator not in the approved selector list."),
            Self::TransactionCountLimitExceeded =>
                write!(f, "DENIED: Agent daily transaction count limit reached."),
        }
    }
}

impl std::error::Error for PolicyDenial {}

/// General SDK errors (I/O, config parsing, network, crypto).
#[derive(Debug)]
pub enum SdkError {
    /// Config file I/O or TOML parse failure.
    ConfigLoad(String),
    /// Invalid Solana address format.
    InvalidAddress(String),
    /// Invalid hex encoding in calldata / selectors.
    InvalidHex(String),
    /// Policy evaluation denied the transaction.
    PolicyDenied(PolicyDenial),
    /// Remote gateway HTTP or parse error.
    GatewayError(String),
}

impl std::fmt::Display for SdkError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::ConfigLoad(e) => write!(f, "Config load error: {e}"),
            Self::InvalidAddress(e) => write!(f, "Invalid address: {e}"),
            Self::InvalidHex(e) => write!(f, "Invalid hex: {e}"),
            Self::PolicyDenied(d) => write!(f, "{d}"),
            Self::GatewayError(e) => write!(f, "Gateway error: {e}"),
        }
    }
}

impl std::error::Error for SdkError {}


// ═══════════════════════════════════════════════════════════════════════
//  SECTION 3: TRANSACTION & RECEIPT TYPES
// ═══════════════════════════════════════════════════════════════════════

/// How the agent identifies itself to the engine.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum AgentId {
    /// Raw numeric agent ID (plaintext — fast path).
    Raw(u64),
    /// SHA-256 hash of the agent's numeric ID string.
    Sha256(Hash256),
    /// BLAKE3 hash of the agent's numeric ID string.
    Blake3(Hash256),
}

impl AgentId {
    /// Serialize to the wire format the server expects.
    pub fn to_wire(&self) -> String {
        match self {
            AgentId::Raw(id) => id.to_string(),
            AgentId::Sha256(h) => fmt_sha256(h),
            AgentId::Blake3(h) => fmt_blake3(h),
        }
    }
}

/// How the recipient address is specified.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Recipient {
    /// Raw Solana Base58 pubkey.
    Raw(String),
    /// SHA-256 hash of the Base58 address string.
    Sha256(Hash256),
    /// BLAKE3 hash of the Base58 address string.
    Blake3(Hash256),
}

impl Recipient {
    /// Serialize to the wire format the server expects.
    pub fn to_wire(&self) -> String {
        match self {
            Recipient::Raw(s) => s.clone(),
            Recipient::Sha256(h) => fmt_sha256(h),
            Recipient::Blake3(h) => fmt_blake3(h),
        }
    }
}

/// A transaction that an AI agent wants to execute.
///
/// Values are in **lamports** (1 SOL = 1_000_000_000 lamports).
/// Priority fee is in micro-lamports per compute unit.
pub struct SdkTransaction {
    /// The agent initiating the transaction.
    pub from_agent: AgentId,
    /// The destination address or hashed address.
    pub to: Recipient,
    /// Value in lamports (u64 for Solana, fits in a U256 slot for the engine).
    pub value_lamports: u64,
    /// Solana priority fee in micro-lamports.
    pub priority_fee: u64,
    /// Solana cluster ID (101=mainnet, 102=devnet, 103=testnet).
    pub cluster_id: u64,
    /// Optional Anchor instruction discriminator + data (raw bytes).
    pub instruction_data: Option<Vec<u8>>,
}

/// Successful evaluation receipt returned by the engine.
#[derive(Debug, Clone)]
pub struct EvalReceipt {
    pub approved: bool,
    pub message: String,
    /// The agent's updated daily spend after this transaction (lamports).
    pub agent_daily_spend: u64,
    /// The agent's updated daily transaction count.
    pub agent_daily_tx_count: u64,
    /// The wallet-wide updated daily spend (lamports).
    pub wallet_daily_spend: u64,
}


// ═══════════════════════════════════════════════════════════════════════
//  SECTION 4: SDK CONFIG — TOML DESERIALIZATION
// ═══════════════════════════════════════════════════════════════════════

/// Deserialized agent configuration block from `config.toml`.
#[derive(Debug, Clone)]
struct SdkAgentConfig {
    /// Maximum value per single transaction (lamports).
    tx_limit: u64,
    /// Maximum cumulative daily spend (lamports).
    daily_cap: u64,
    /// Maximum number of transactions per day.
    daily_tx_count_limit: u64,
}

/// Mutable agent runtime state — spend counters.
#[derive(Debug, Default)]
struct SdkAgentState {
    daily_spend: AtomicU64,
    daily_tx_count: AtomicU64,
}

/// Parsed wallet-level policy configuration.
#[derive(Debug)]
struct SdkWalletConfig {
    kill_switch: AtomicBool,
    allowed_chain_id: u64,
    wallet_tx_limit: u64,
    wallet_daily_cap: u64,
    max_priority_fee: u64,
    contract_calls_allowed: bool,
    /// Set of raw 32-byte Solana pubkeys in the recipient whitelist.
    recipient_whitelist: HashSet<[u8; 32]>,
    /// Set of instruction discriminator byte prefixes.
    function_selector_whitelist: HashSet<Vec<u8>>,
}

/// Raw TOML representation — mirrors `config.toml` layout exactly.
#[derive(Deserialize)]
struct RawConfigFile {
    wallet: RawWallet,
    agents: HashMap<String, RawAgent>,
}

#[derive(Deserialize)]
struct RawWallet {
    kill_switch: bool,
    allowed_chain_id: u64,
    wallet_tx_limit: String,
    wallet_daily_cap: String,
    max_gas_price_gwei: u64,
    contract_calls_allowed: bool,
    recipient_whitelist: Vec<String>,
    function_selector_whitelist: Vec<String>,
}

#[derive(Deserialize)]
struct RawAgent {
    tx_limit: String,
    daily_cap: String,
    daily_tx_count_limit: u64,
}

/// Parse a Uint256-style string (decimal or `0x` hex) into a u64.
/// The engine uses U256 internally but Solana operates on u64 lamports.
fn parse_limit_value(s: &str) -> Result<u64, SdkError> {
    let s = s.trim();
    if let Some(h) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        u64::from_str_radix(h, 16)
            .map_err(|e| SdkError::ConfigLoad(format!("bad hex limit '{}': {}", s, e)))
    } else {
        s.parse::<u64>()
            .map_err(|e| SdkError::ConfigLoad(format!("bad decimal limit '{}': {}", s, e)))
    }
}

/// Decode a hex string (with optional `0x` prefix) into raw bytes.
fn decode_hex_selector(s: &str) -> Result<Vec<u8>, SdkError> {
    let clean = s.strip_prefix("0x")
        .or_else(|| s.strip_prefix("0X"))
        .unwrap_or(s);
    hex::decode(clean)
        .map_err(|e| SdkError::InvalidHex(format!("selector '{}': {}", s, e)))
}


// ═══════════════════════════════════════════════════════════════════════
//  SECTION 5: THE SDK CORE — PrivTractSDK
// ═══════════════════════════════════════════════════════════════════════

/// The Priv-Tract Policy Engine SDK.
///
/// Operates in two modes:
///
/// 1. **Embedded** — loaded from `config.toml`, evaluates all policy rules
///    locally in-process with zero network I/O. Ideal for high-frequency
///    trading bots and autonomous agents that need sub-microsecond latency.
///
/// 2. **Gateway** — connects to a remote `priv-tract-server` over HTTP.
///    Useful for multi-service architectures where a centralized policy
///    server manages shared state across multiple agents.
pub struct PrivTractSDK {
    // ── Embedded mode fields ──
    wallet: Option<SdkWalletConfig>,
    agents: HashMap<u64, (SdkAgentConfig, SdkAgentState)>,
    wallet_daily_spend: AtomicU64,

    // ── Gateway mode fields ──
    server_url: Option<String>,
    admin_token: Option<String>,
    http_client: reqwest::Client,
}

impl PrivTractSDK {
    // ─────────────────────────────────────────────────────────
    //  CONSTRUCTORS
    // ─────────────────────────────────────────────────────────

    /// Create an SDK instance in **embedded mode** from a `config.toml` file.
    ///
    /// Parses the TOML configuration, decodes all Base58 addresses in the
    /// recipient whitelist, hex-decodes function selectors, and initializes
    /// agent spend counters to zero.
    pub fn from_config(path: &str) -> Result<Self, SdkError> {
        let raw_text = std::fs::read_to_string(path)
            .map_err(|e| SdkError::ConfigLoad(format!("{}: {}", path, e)))?;

        let raw: RawConfigFile = toml::from_str(&raw_text)
            .map_err(|e| SdkError::ConfigLoad(format!("TOML parse: {e}")))?;

        // Parse recipient whitelist — Base58 Solana pubkeys → raw [u8; 32]
        let mut whitelist = HashSet::new();
        for addr_str in &raw.wallet.recipient_whitelist {
            let pubkey = decode_solana_pubkey(addr_str)?;
            whitelist.insert(pubkey);
        }

        // Parse function selector whitelist
        let mut selectors = HashSet::new();
        for sel_str in &raw.wallet.function_selector_whitelist {
            let sel_bytes = decode_hex_selector(sel_str)?;
            selectors.insert(sel_bytes);
        }

        let wallet_cfg = SdkWalletConfig {
            kill_switch: AtomicBool::new(raw.wallet.kill_switch),
            allowed_chain_id: raw.wallet.allowed_chain_id,
            wallet_tx_limit: parse_limit_value(&raw.wallet.wallet_tx_limit)?,
            wallet_daily_cap: parse_limit_value(&raw.wallet.wallet_daily_cap)?,
            max_priority_fee: raw.wallet.max_gas_price_gwei,
            contract_calls_allowed: raw.wallet.contract_calls_allowed,
            recipient_whitelist: whitelist,
            function_selector_whitelist: selectors,
        };

        let mut agents_map = HashMap::new();
        for (id_str, raw_agent) in &raw.agents {
            let id: u64 = id_str.parse()
                .map_err(|e| SdkError::ConfigLoad(format!("bad agent id '{}': {}", id_str, e)))?;
            let cfg = SdkAgentConfig {
                tx_limit: parse_limit_value(&raw_agent.tx_limit)?,
                daily_cap: parse_limit_value(&raw_agent.daily_cap)?,
                daily_tx_count_limit: raw_agent.daily_tx_count_limit,
            };
            agents_map.insert(id, (cfg, SdkAgentState::default()));
        }

        Ok(Self {
            wallet: Some(wallet_cfg),
            agents: agents_map,
            wallet_daily_spend: AtomicU64::new(0),
            server_url: None,
            admin_token: None,
            http_client: reqwest::Client::new(),
        })
    }

    /// Create an SDK instance in **gateway mode** pointing at a remote server.
    pub fn gateway(server_url: &str, admin_token: Option<String>) -> Self {
        Self {
            wallet: None,
            agents: HashMap::new(),
            wallet_daily_spend: AtomicU64::new(0),
            server_url: Some(server_url.trim_end_matches('/').to_string()),
            admin_token,
            http_client: reqwest::Client::new(),
        }
    }

    // ─────────────────────────────────────────────────────────
    //  CRYPTOGRAPHIC HELPERS
    // ─────────────────────────────────────────────────────────

    /// Hash an agent's numeric ID with SHA-256 for privacy-preserving submission.
    ///
    /// The engine stores agents by numeric ID internally. When sending a
    /// transaction over untrusted channels, hashing the ID prevents
    /// correlation attacks from network observers.
    pub fn hash_agent_sha256(&self, agent_id: u64) -> AgentId {
        AgentId::Sha256(sha256_str(&agent_id.to_string()))
    }

    /// Hash an agent's numeric ID with BLAKE3 for privacy-preserving submission.
    pub fn hash_agent_blake3(&self, agent_id: u64) -> AgentId {
        AgentId::Blake3(blake3_str(&agent_id.to_string()))
    }

    /// Hash a Solana Base58 address with SHA-256 for private recipient matching.
    ///
    /// The engine's recipient whitelist comparison works by hashing each
    /// stored raw address and comparing against the submitted hash in
    /// constant time via `ct_hash_eq`.
    pub fn hash_address_sha256(&self, address: &str) -> Recipient {
        Recipient::Sha256(sha256_str(address))
    }

    /// Hash a Solana Base58 address with BLAKE3 for private recipient matching.
    pub fn hash_address_blake3(&self, address: &str) -> Recipient {
        Recipient::Blake3(blake3_str(address))
    }

    /// Compute dual hashes (SHA-256 + BLAKE3) of an agent ID. Useful for
    /// displaying both fingerprints in audit dashboards.
    pub fn dual_hash_agent(&self, agent_id: u64) -> (String, String) {
        let id_str = agent_id.to_string();
        (fmt_sha256(&sha256_str(&id_str)), fmt_blake3(&blake3_str(&id_str)))
    }

    // ─────────────────────────────────────────────────────────
    //  EMBEDDED POLICY EVALUATION ENGINE
    // ─────────────────────────────────────────────────────────

    /// Evaluate a transaction against all policy rules **locally**.
    ///
    /// This is a zero-allocation fast path that mirrors the Rust server
    /// engine's `validate_transaction` method exactly. The enforcement
    /// pipeline executes in the following deterministic order:
    ///
    /// 1. **Kill switch** — global emergency halt
    /// 2. **Cluster ID** — network target verification
    /// 3. **Priority fee** — gas/fee ceiling
    /// 4. **Recipient whitelist** — allowlist gate (raw or hashed)
    /// 5. **Instruction selector** — discriminator allowlist
    /// 6. **Agent authentication** — identity resolution (raw or hashed)
    /// 7. **Per-tx value limit** — min(agent_limit, wallet_limit)
    /// 8. **Agent daily cap** — cumulative spend check
    /// 9. **Agent daily tx count** — frequency limiter
    /// 10. **Wallet daily cap** — global cumulative spend
    /// 11. **Atomic commit** — all counters updated together
    pub fn evaluate(&self, tx: &SdkTransaction) -> Result<EvalReceipt, SdkError> {
        let wallet = self.wallet.as_ref()
            .ok_or_else(|| SdkError::ConfigLoad(
                "SDK not in embedded mode — call from_config() or use evaluate_remote()".into()
            ))?;

        // ── GATE 1: Kill Switch ──
        if wallet.kill_switch.load(Ordering::Acquire) {
            return Err(SdkError::PolicyDenied(PolicyDenial::KillSwitchActive));
        }

        // ── GATE 2: Cluster / Chain ID ──
        if tx.cluster_id != wallet.allowed_chain_id {
            return Err(SdkError::PolicyDenied(PolicyDenial::ClusterIdMismatch));
        }

        // ── GATE 3: Priority Fee Ceiling ──
        if tx.priority_fee > wallet.max_priority_fee {
            return Err(SdkError::PolicyDenied(PolicyDenial::PriorityFeeTooHigh));
        }

        // ── GATE 4: Recipient Whitelist ──
        let recipient_ok = match &tx.to {
            Recipient::Raw(addr_str) => {
                match decode_solana_pubkey(addr_str) {
                    Ok(pubkey) => wallet.recipient_whitelist.contains(&pubkey),
                    Err(_) => false,
                }
            }
            Recipient::Sha256(submitted_hash) => {
                wallet.recipient_whitelist.iter().any(|raw_pubkey| {
                    let addr_str = encode_solana_pubkey(raw_pubkey);
                    let computed = sha256_str(&addr_str);
                    ct_hash_eq(&computed, submitted_hash)
                })
            }
            Recipient::Blake3(submitted_hash) => {
                wallet.recipient_whitelist.iter().any(|raw_pubkey| {
                    let addr_str = encode_solana_pubkey(raw_pubkey);
                    let computed = blake3_str(&addr_str);
                    ct_hash_eq(&computed, submitted_hash)
                })
            }
        };
        if !recipient_ok {
            return Err(SdkError::PolicyDenied(PolicyDenial::RecipientNotWhitelisted));
        }

        // ── GATE 5: Instruction Discriminator ──
        if let Some(data) = &tx.instruction_data {
            if !wallet.contract_calls_allowed {
                return Err(SdkError::PolicyDenied(PolicyDenial::InstructionCallsNotAllowed));
            }
            let matched = wallet.function_selector_whitelist.iter().any(|sel| {
                data.starts_with(sel)
            });
            if !matched {
                return Err(SdkError::PolicyDenied(PolicyDenial::InstructionSelectorNotWhitelisted));
            }
        }

        // ── GATE 6: Agent Authentication ──
        let agent_id = match &tx.from_agent {
            AgentId::Raw(id) => {
                if !self.agents.contains_key(id) {
                    return Err(SdkError::PolicyDenied(PolicyDenial::AgentNotAuthenticated));
                }
                *id
            }
            AgentId::Sha256(submitted_hash) => {
                let found = self.agents.keys().find(|&&id| {
                    let computed = sha256_str(&id.to_string());
                    ct_hash_eq(&computed, submitted_hash)
                });
                match found {
                    Some(&id) => id,
                    None => return Err(SdkError::PolicyDenied(PolicyDenial::AgentNotAuthenticated)),
                }
            }
            AgentId::Blake3(submitted_hash) => {
                let found = self.agents.keys().find(|&&id| {
                    let computed = blake3_str(&id.to_string());
                    ct_hash_eq(&computed, submitted_hash)
                });
                match found {
                    Some(&id) => id,
                    None => return Err(SdkError::PolicyDenied(PolicyDenial::AgentNotAuthenticated)),
                }
            }
        };

        let (agent_cfg, agent_state) = self.agents.get(&agent_id).unwrap();
        let value = tx.value_lamports;

        // ── GATE 7: Per-Transaction Value Limit ──
        let limit = std::cmp::min(agent_cfg.tx_limit, wallet.wallet_tx_limit);
        if value > limit {
            return Err(SdkError::PolicyDenied(PolicyDenial::TransactionLimitExceeded));
        }

        // ── GATE 8: Agent Daily Spend Cap ──
        let current_agent_spend = agent_state.daily_spend.load(Ordering::Acquire);
        if current_agent_spend + value > agent_cfg.daily_cap {
            return Err(SdkError::PolicyDenied(PolicyDenial::AgentDailyCapExceeded));
        }

        // ── GATE 9: Agent Daily Transaction Count ──
        let current_agent_tx_count = agent_state.daily_tx_count.load(Ordering::Acquire);
        if current_agent_tx_count + 1 > agent_cfg.daily_tx_count_limit {
            return Err(SdkError::PolicyDenied(PolicyDenial::TransactionCountLimitExceeded));
        }

        // ── GATE 10: Wallet-Wide Daily Cap ──
        let current_wallet_spend = self.wallet_daily_spend.load(Ordering::Acquire);
        if current_wallet_spend + value > wallet.wallet_daily_cap {
            return Err(SdkError::PolicyDenied(PolicyDenial::WalletDailyCapExceeded));
        }

        // ── GATE 11: Atomic Commit ──
        // Update all counters. In a single-threaded agent context these are
        // sequentially consistent. For multi-threaded agents, the Acquire/Release
        // ordering ensures visibility across cores without a full mutex.
        let new_agent_spend = agent_state.daily_spend.fetch_add(value, Ordering::AcqRel) + value;
        let new_agent_count = agent_state.daily_tx_count.fetch_add(1, Ordering::AcqRel) + 1;
        let new_wallet_spend = self.wallet_daily_spend.fetch_add(value, Ordering::AcqRel) + value;

        Ok(EvalReceipt {
            approved: true,
            message: format!(
                "Transaction APPROVED — {} lamports ({:.4} SOL) from agent {} to {}",
                value,
                value as f64 / 1_000_000_000.0,
                agent_id,
                tx.to.to_wire(),
            ),
            agent_daily_spend: new_agent_spend,
            agent_daily_tx_count: new_agent_count,
            wallet_daily_spend: new_wallet_spend,
        })
    }

    /// Reset all daily spend counters to zero. Call at midnight UTC.
    pub fn reset_daily_state(&self) {
        self.wallet_daily_spend.store(0, Ordering::Release);
        for (_, (_, state)) in &self.agents {
            state.daily_spend.store(0, Ordering::Release);
            state.daily_tx_count.store(0, Ordering::Release);
        }
    }

    /// Activate or deactivate the global kill switch (embedded mode).
    pub fn set_kill_switch(&self, active: bool) {
        if let Some(ref wallet) = self.wallet {
            wallet.kill_switch.store(active, Ordering::Release);
        }
    }

    // ─────────────────────────────────────────────────────────
    //  REMOTE GATEWAY API
    // ─────────────────────────────────────────────────────────

    /// Evaluate a transaction via the remote `priv-tract-server` gateway.
    pub async fn evaluate_remote(&self, tx: &SdkTransaction) -> Result<GatewayResponse, SdkError> {
        let base = self.server_url.as_ref()
            .ok_or_else(|| SdkError::GatewayError("No server URL configured".into()))?;

        let payload = serde_json::json!({
            "from_agent": tx.from_agent.to_wire(),
            "to": tx.to.to_wire(),
            "value": tx.value_lamports.to_string(),
            "gas_price_gwei": tx.priority_fee,
            "chain_id": tx.cluster_id,
            "calldata": tx.instruction_data.as_ref().map(|d| format!("0x{}", hex::encode(d))),
        });

        let resp = self.http_client
            .post(format!("{}/api/validate", base))
            .json(&payload)
            .send()
            .await
            .map_err(|e| SdkError::GatewayError(format!("HTTP request failed: {e}")))?;

        let status = resp.status();
        let body: GatewayResponse = resp.json().await
            .map_err(|e| SdkError::GatewayError(format!("Response parse error: {e}")))?;

        if status.is_success() {
            Ok(body)
        } else {
            Err(SdkError::PolicyDenied(PolicyDenial::AgentNotAuthenticated))
        }
    }

    /// Fetch the full engine state from the remote server.
    pub async fn get_remote_state(&self) -> Result<RemoteState, SdkError> {
        let base = self.server_url.as_ref()
            .ok_or_else(|| SdkError::GatewayError("No server URL configured".into()))?;

        let resp = self.http_client
            .get(format!("{}/api/state", base))
            .send()
            .await
            .map_err(|e| SdkError::GatewayError(format!("HTTP: {e}")))?;

        resp.json::<RemoteState>().await
            .map_err(|e| SdkError::GatewayError(format!("Parse: {e}")))
    }

    /// Toggle the kill switch on the remote server (requires admin token).
    pub async fn remote_toggle_kill_switch(&self, active: bool) -> Result<GatewayResponse, SdkError> {
        let base = self.server_url.as_ref()
            .ok_or_else(|| SdkError::GatewayError("No server URL configured".into()))?;
        let token = self.admin_token.as_ref()
            .ok_or_else(|| SdkError::GatewayError("Admin token not configured".into()))?;

        let resp = self.http_client
            .post(format!("{}/api/kill-switch", base))
            .header("x-admin-token", token)
            .json(&serde_json::json!({ "active": active }))
            .send()
            .await
            .map_err(|e| SdkError::GatewayError(format!("HTTP: {e}")))?;

        resp.json::<GatewayResponse>().await
            .map_err(|e| SdkError::GatewayError(format!("Parse: {e}")))
    }

    /// Register a new agent on the remote server (requires admin token).
    pub async fn remote_register_agent(
        &self,
        agent_id: u64,
        tx_limit: &str,
        daily_cap: &str,
        daily_tx_count_limit: u64,
    ) -> Result<GatewayResponse, SdkError> {
        let base = self.server_url.as_ref()
            .ok_or_else(|| SdkError::GatewayError("No server URL configured".into()))?;
        let token = self.admin_token.as_ref()
            .ok_or_else(|| SdkError::GatewayError("Admin token not configured".into()))?;

        let resp = self.http_client
            .post(format!("{}/api/agents", base))
            .header("x-admin-token", token)
            .json(&serde_json::json!({
                "id": agent_id,
                "tx_limit": tx_limit,
                "daily_cap": daily_cap,
                "daily_tx_count_limit": daily_tx_count_limit,
            }))
            .send()
            .await
            .map_err(|e| SdkError::GatewayError(format!("HTTP: {e}")))?;

        resp.json::<GatewayResponse>().await
            .map_err(|e| SdkError::GatewayError(format!("Parse: {e}")))
    }

    /// Update policies on the remote server (requires admin token).
    pub async fn remote_update_policies(
        &self,
        policies: serde_json::Value,
    ) -> Result<GatewayResponse, SdkError> {
        let base = self.server_url.as_ref()
            .ok_or_else(|| SdkError::GatewayError("No server URL configured".into()))?;
        let token = self.admin_token.as_ref()
            .ok_or_else(|| SdkError::GatewayError("Admin token not configured".into()))?;

        let resp = self.http_client
            .post(format!("{}/api/policies", base))
            .header("x-admin-token", token)
            .json(&policies)
            .send()
            .await
            .map_err(|e| SdkError::GatewayError(format!("HTTP: {e}")))?;

        resp.json::<GatewayResponse>().await
            .map_err(|e| SdkError::GatewayError(format!("Parse: {e}")))
    }
}


// ═══════════════════════════════════════════════════════════════════════
//  SECTION 6: GATEWAY RESPONSE TYPES
// ═══════════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GatewayResponse {
    pub status: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RemoteAgentInfo {
    pub tx_limit: String,
    pub daily_cap: String,
    pub daily_spend: String,
    pub daily_tx_count_limit: u64,
    pub daily_tx_count: u64,
    pub sha256_hash: String,
    pub blake3_hash: String,
    pub sol_balance: String,
    pub usdc_balance: String,
    pub bonk_balance: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RemoteState {
    pub wallet_daily_spend: String,
    pub wallet_daily_cap: String,
    pub wallet_tx_limit: String,
    pub kill_switch: bool,
    pub allowed_chain_id: u64,
    pub max_gas_price_gwei: u64,
    pub contract_calls_allowed: bool,
    pub recipient_whitelist: Vec<String>,
    pub function_selector_whitelist: Vec<String>,
    pub agents: HashMap<String, RemoteAgentInfo>,
    pub admin_controls_configured: bool,
}
